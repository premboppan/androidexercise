package com.example.macstudent.registration;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private static EditText username;
    private static EditText password;
    private static Button loginbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
    public  void LoginButton() {
        username = (EditText)findViewById(R.id.user);
        password = (EditText)findViewById(R.id.pass);
        loginbutton = (Button)findViewById(R.id.loginbutton);


    }

}
